#include "../gdiplusUI.h"

GdiplusUI::Components::Screen::Screen() : Frame() { m_hTargetWnd = NULL; }

GdiplusUI::Components::Screen::Screen(Rect rcControl) : Frame(rcControl) {
  m_hTargetWnd = NULL;
}

void GdiplusUI::Components::Screen::BindWindow(HWND hWnd) {
  m_hTargetWnd = hWnd;
}
