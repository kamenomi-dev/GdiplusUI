#pragma once

#include <assert.h>

#include <Windows.h>
#include <gdiplus.h>

#pragma comment(lib, "Gdiplus.lib")

using namespace Gdiplus;

extern bool g_globalInit;

#define CHECK_CORRECT_INIT()                                                   \
  assert(g_globalInit && "Oops, you call this dll by Thread! ");


#include "./gdiplusUI.h"