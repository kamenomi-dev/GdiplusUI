#include "./gdiplusUI.h"

GdiplusUI::LogicManager::LogicManager(RenderManager* renderManager) {
  m_hMessageWnd   = renderManager->GetRenderWindow();
  m_renderManager = renderManager;
}

GdiplusUI::LogicManager::~LogicManager() {}


LRESULT GdiplusUI::LogicManager::MessageHandler(
    HWND   hWnd,
    UINT   uMsg,
    WPARAM wParam,
    LPARAM lParam
) {
  static SwapChain* swapChain;  // Need to check nullpointer.

  if (uMsg == WM_CREATE) {
    swapChain = m_renderManager->GetSwapContext();
  }

  if (uMsg == WM_SIZE) {
    assert(swapChain);
    swapChain->Resize(lParam);
    return 0;
  }


  // Handle WM_PAINT
  if (uMsg == WM_PAINT) {
    assert(swapChain);

    auto presentGrap = new Graphics(swapChain->GetLayoutDC());

    PostMessageEventToAll(WM_PAINT, NULL, (LPARAM)presentGrap);

    delete presentGrap;
    swapChain->Present();
    return 0;
  }


  if (uMsg == WM_ERASEBKGND) {
    return 0;
  }

  return DefWindowProcW(hWnd, uMsg, wParam, lParam);
}

/// <summary>
/// Call All the children controls of root(screen) control. (including screen.)
/// </summary>
void GdiplusUI::LogicManager::PostMessageEventToAll(
    UINT   uMsg,
    WPARAM wParam,
    LPARAM lParam
) {
  const auto root = m_renderManager->GetControlRoot();
  root->__MessageHandler(uMsg, wParam, lParam);
  _PostMessageEventToAll(root, uMsg, wParam, lParam);
}

void GdiplusUI::LogicManager::PostMessageEventToTarget(
    Control* target,
    UINT     uMsg,
    WPARAM   wParam,
    LPARAM   lParam,
    bool     enableBubble
) {
  _PostMessageEventToTarget(target, uMsg, wParam, lParam, enableBubble);
}

/// <summary>
/// Call All the children controls of parent control. (including parent.)
/// </summary>
void GdiplusUI::LogicManager::_PostMessageEventToAll(
    Control* parent,
    UINT     uMsg,
    WPARAM   wParam,
    LPARAM   lParam
) {
  auto& children = parent->GetChildren();
  for (auto item : children) {
    _PostMessageEventToAll(item, uMsg, wParam, lParam);
  }

  parent->__MessageHandler(uMsg, wParam, lParam);
}

/// <summary>
/// Todo. Let it supports the target controls which is targeted is saved in
/// argument.
/// </summary>
void GdiplusUI::LogicManager::_PostMessageEventToTarget(
    Control* target,
    UINT     uMsg,
    WPARAM   wParam,
    LPARAM   lParam,
    bool     enableBubble
) {
  target->__MessageHandler(uMsg, wParam, lParam);

  if (not enableBubble) {
    return;
  }

  auto parent = target->GetParent();
  if (parent) {
    _PostMessageEventToTarget(parent, uMsg, wParam, lParam);
  };
}
