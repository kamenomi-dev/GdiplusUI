#pragma once

#ifndef _LOGICMANAGER_H_
#define _LOGICMANAGER_H_

namespace GdiplusUI {
class LogicManager : INonCopy {
  public:
  LogicManager(RenderManager* renderManager);
  ~LogicManager();


  LRESULT MessageHandler(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);


  void PostMessageEventToAll(UINT uMsg, WPARAM wParam, LPARAM lParam);
  void PostMessageEventToTarget(
      Control* target,
      UINT     uMsg,
      WPARAM   wParam,
      LPARAM   lParam,
      bool     enableBubble = false
  );

  private:
  void _PostMessageEventToAll(
      Control* parent,
      UINT     uMsg,
      WPARAM   wParam,
      LPARAM   lParam
  );
  void _PostMessageEventToTarget(
      Control* target,
      UINT     uMsg,
      WPARAM   wParam,
      LPARAM   lParam,
      bool     enableBubble
  );

  private:
  HWND           m_hMessageWnd;
  RenderManager* m_renderManager;
};
} // namespace GdiplusUI

#endif // !_GDIPLUS_LOGICMANAGER_H_
