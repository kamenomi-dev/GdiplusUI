#include "../gdiplusUI.h"

GdiplusUI::Utils::Gdiplus::SwapChain::SwapChain() {
  m_hTargetWnd = NULL;
  m_szWnd      = Size();

  m_hVirtualDC        = CreateCompatibleDC(NULL);
  m_hVirtualBitmap    = NULL;
  m_hVirtualBitmapOld = NULL;
}

GdiplusUI::Utils::Gdiplus::SwapChain::~SwapChain() {
  if (m_hVirtualDC) {
    if (m_hVirtualBitmapOld) {
      SelectBitmap(m_hVirtualDC, m_hVirtualBitmapOld);
      DeleteBitmap(m_hVirtualBitmap);

      m_hVirtualBitmap    = NULL;
      m_hVirtualBitmapOld = NULL;
    }

    DeleteDC(m_hVirtualDC);
    m_hVirtualDC = NULL;
  }
}

HDC GdiplusUI::Utils::Gdiplus::SwapChain::GetLayoutDC() const {
  return m_hVirtualDC;
}

void GdiplusUI::Utils::Gdiplus::SwapChain::Bind(HWND hWnd) {
  m_hTargetWnd = hWnd;
}

void GdiplusUI::Utils::Gdiplus::SwapChain::Present() { 
  auto targetDC = GetDC(m_hTargetWnd);

  BitBlt(targetDC, 0, 0, m_szWnd.Width, m_szWnd.Height, GetLayoutDC(), 0, 0, SRCCOPY);

  ReleaseDC(m_hTargetWnd, targetDC);
}

void GdiplusUI::Utils::Gdiplus::SwapChain::Resize() {
  RECT rcWnd{};
  GetWindowRect(m_hTargetWnd, &rcWnd);

  Resize(MAKELPARAM(rcWnd.right - rcWnd.left, rcWnd.bottom - rcWnd.top));
}

void GdiplusUI::Utils::Gdiplus::SwapChain::Resize(LPARAM data) {
  m_szWnd.Width  = GET_X_LPARAM(data);
  m_szWnd.Height = GET_Y_LPARAM(data);

  if (m_hVirtualBitmapOld) {
    m_hVirtualBitmap = SelectBitmap(m_hVirtualDC, m_hVirtualBitmapOld);
    DeleteBitmap(m_hVirtualBitmap);
  }

  m_hVirtualBitmap =
      CreateCompatibleBitmap(m_hVirtualDC, m_szWnd.Width, m_szWnd.Height);
  m_hVirtualBitmapOld = SelectBitmap(m_hVirtualDC, m_hVirtualBitmap);
  Present();
}
