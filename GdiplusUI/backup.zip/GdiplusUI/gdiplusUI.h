
#pragma warning(disable : 4251)

#include <assert.h>
#include <string>
#include <vector>

#include <Windows.h>
#include <Windowsx.h>
#include <gdiplus.h>

using namespace Gdiplus;
using std::wstring;
using std::vector;

#ifdef GDIPLUSUI_EXPORTS
#define GpUI_API _declspec(dllexport)
#else
#define GpUI_API _declspec(dllimport)
#endif

#include "./Interface.h"

#include "./Utils/GdiplusUtils.h"

#include "./Components/Control.h"
#include "./Components/Frame.h"
#include "./Components/Screen.h"

#include "./RenderManager.h"
#include "./LogicManager.h"
